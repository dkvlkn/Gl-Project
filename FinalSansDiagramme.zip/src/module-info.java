/**
 * 
 */
/**
 * 
 */
module ProjetGLP2 {
	requires java.desktop;
	requires java.instrument;
	requires java.base; 
	requires java.datatransfer;
}